const tarotMessages = [
    {
        message: "O universo está conspirando a seu favor. Confie no processo.",
        audio: "audio/mystical1.mp3"
    },
    {
        message: "Momentos de transformação estão chegando. Esteja preparado para mudanças positivas.",
        audio: "audio/mystical2.mp3"
    },
    {
        message: "Sua intuição está mais forte que nunca. Siga seus instintos.",
        audio: "audio/mystical3.mp3"
    },
    {
        message: "Novas oportunidades estão surgindo. Mantenha os olhos abertos.",
        audio: "audio/mystical4.mp3"
    },
    {
        message: "O amor está no ar. Prepare-se para encontros significativos.",
        audio: "audio/mystical5.mp3"
    }
]; 